README

HOW TO RUN THE PROGRAM

First, run the cells with the imports, then run the other cells from top to bottom.

Please not, there are two cells that have for loops in them; run those cells ONLY once.  Running them more than that can cause the data to skew and mess up the the project.